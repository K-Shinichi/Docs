import time
import os
from datetime import datetime, timedelta
from influxdb_client import InfluxDBClient, Point
from influxdb_client.client.write_api import SYNCHRONOUS
from dotenv import load_dotenv
import requests
from xml.etree import ElementTree

load_dotenv()

ENTSOE_TOKEN = os.getenv("ENTSOE_TOKEN")
INFLUXDB_TOKEN = os.getenv("INFLUXDB_TOKEN")
INFLUXDB_URL = os.getenv("INFLUXDB_URL")
INFLUXDB_ORG = os.getenv("INFLUXDB_ORG")
INFLUXDB_BUCKET = os.getenv("INFLUXDB_BUCKET")

def fetch_frequency_entsoe():
    now = datetime.utcnow()
    start = (now - timedelta(hours=1)).strftime("%Y%m%d%H%M")
    end = now.strftime("%Y%m%d%H%M")

    url = (
        "https://transparency.entsoe.eu/api?"
        f"documentType=A75&processType=A16&outBiddingZone_Domain=10Y1001A1001A63L"
        f"&periodStart={start}&periodEnd={end}&securityToken={ENTSOE_TOKEN}"
    )

    response = requests.get(url)
    if response.status_code != 200:
        print("Erreur API ENTSO-E :", response.text)
        return 50.00

    root = ElementTree.fromstring(response.content)
    ns = {'ns': 'urn:iec62325.351:tc57wg16:451-6:publicationdocument:7:0'}
    values = root.findall('.//ns:Point', ns)

    if not values:
        print("Aucune donnée de fréquence trouvée")
        return 50.00

    last = values[-1]
    hz = float(last.find('ns:quantity', ns).text)
    return hz

def fetch_spot_prices_entsoe():
    now = datetime.utcnow()
    start = (now - timedelta(days=1)).strftime("%Y%m%d0000")
    end = now.strftime("%Y%m%d2300")

    url = (
        "https://web-api.tp.entsoe.eu/api"
        f"?documentType=A44"
        f"&in_Domain=10YFR-RTE------C"
        f"&out_Domain=10YFR-RTE------C"
        f"&periodStart={start}"
        f"&periodEnd={end}"
        f"&securityToken={ENTSOE_TOKEN}"
    )

    try:
        response = requests.get(url)
        response.raise_for_status()
    except requests.RequestException as e:
        print("Erreur API ENTSO-E (spot prices):", e)
        return []

    ns = {'ns': 'urn:iec62325.351:tc57wg16:451-3:publicationdocument:7:0'}
    root = ElementTree.fromstring(response.content)
    timeseries = root.findall(".//ns:TimeSeries", ns)

    points = []

    for ts in timeseries:
        start = ts.find(".//ns:timeInterval/ns:start", ns).text
        start_dt = datetime.fromisoformat(start)
        price_points = ts.findall(".//ns:Point", ns)

        for i, pt in enumerate(price_points):
            price = float(pt.find("ns:price.amount", ns).text)
            ts_point = start_dt + timedelta(hours=i)

            point = Point("spot_price_epex")                 .tag("market", "day_ahead")                 .field("price_eur_mwh", price)                 .time(ts_point)

            points.append(point)

    return points

def fetch_realtime_services():
    now = datetime.utcnow()
    start = (now - timedelta(hours=1)).strftime("%Y%m%d%H%M")
    end = now.strftime("%Y%m%d%H%M")

    url = (
        "https://web-api.tp.entsoe.eu/api"
        f"?documentType=A75"
        f"&processType=A16"
        f"&outBiddingZone_Domain=10YFR-RTE------C"
        f"&periodStart={start}"
        f"&periodEnd={end}"
        f"&securityToken={ENTSOE_TOKEN}"
    )

    response = requests.get(url)
    if response.status_code != 200:
        print("Erreur API ENTSO-E (real services):", response.text)
        return []

    root = ElementTree.fromstring(response.content)
    ns = {'ns': 'urn:iec62325.351:tc57wg16:451-6:publicationdocument:7:0'}
    timeseries = root.findall(".//ns:TimeSeries", ns)

    points = []
    for ts in timeseries:
        product = ts.find("ns:product", ns)
        if product is None:
            continue

        product_type = product.text
        start_time = ts.find(".//ns:timeInterval/ns:start", ns).text
        start_dt = datetime.fromisoformat(start_time)

        for i, pt in enumerate(ts.findall(".//ns:Point", ns)):
            quantity = float(pt.find("ns:quantity", ns).text)
            timestamp = start_dt + timedelta(minutes=15 * i)

            if product_type == "A07":
                measurement = "real_afrr_activations"
            elif product_type == "A09":
                measurement = "real_mfrr_activations"
            else:
                continue

            points.append(
                Point(measurement)
                .field("mw", quantity)
                .time(timestamp)
            )
    return points

def write_to_influx(points):
    if not points:
        return

    client = InfluxDBClient(url=INFLUXDB_URL, token=INFLUXDB_TOKEN, org=INFLUXDB_ORG)
    write_api = client.write_api(write_options=SYNCHRONOUS)
    write_api.write(bucket=INFLUXDB_BUCKET, record=points)
    client.close()

if __name__ == "__main__":
    while True:
        freq = fetch_frequency_entsoe()
        now = datetime.utcnow()
        client = InfluxDBClient(url=INFLUXDB_URL, token=INFLUXDB_TOKEN, org=INFLUXDB_ORG)
        write_api = client.write_api(write_options=SYNCHRONOUS)
        write_api.write(bucket=INFLUXDB_BUCKET, record=Point("frequency_data").field("hz", freq).time(now))
        client.close()

        real_points = fetch_realtime_services()
        write_to_influx(real_points)

        if now.hour == 0 and now.minute < 10:
            spot_points = fetch_spot_prices_entsoe()
            write_to_influx(spot_points)

        time.sleep(300)
