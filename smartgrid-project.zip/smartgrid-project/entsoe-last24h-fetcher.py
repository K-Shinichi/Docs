
import os
from datetime import datetime, timedelta
from rtdip_sdk.pipelines.sources import PythonEntsoeSource
from influxdb_client import InfluxDBClient, Point
from influxdb_client.client.write_api import SYNCHRONOUS
from dotenv import load_dotenv

load_dotenv()

# Variables d'environnement
ENTSOE_TOKEN = os.getenv("ENTSOE_TOKEN")
INFLUXDB_TOKEN = os.getenv("INFLUXDB_TOKEN")
INFLUXDB_URL = os.getenv("INFLUXDB_URL")
INFLUXDB_ORG = os.getenv("INFLUXDB_ORG")
INFLUXDB_BUCKET = os.getenv("INFLUXDB_BUCKET")

def write_dataframe_to_influx(df, measurement_name, value_column, time_column="timestamp"):
    if df.empty:
        print(f"⚠️ Données vides pour {measurement_name}")
        return

    client = InfluxDBClient(url=INFLUXDB_URL, token=INFLUXDB_TOKEN, org=INFLUXDB_ORG)
    write_api = client.write_api(write_options=SYNCHRONOUS)

    for _, row in df.iterrows():
        try:
            point = Point(measurement_name)                 .field("value", float(row[value_column]))                 .time(row[time_column])
            write_api.write(bucket=INFLUXDB_BUCKET, record=point)
        except Exception as e:
            print(f"Erreur lors de l'écriture d'un point {measurement_name} :", e)

    client.close()
    print(f"✅ {measurement_name} écrit ({len(df)} points)")

def fetch_and_store_data():
    # Période : J-2 (ENTSO-E a souvent du délai)
    end = datetime.utcnow() - timedelta(days=1)
    start = end - timedelta(days=1)

    start_str = start.strftime("%Y%m%d")
    end_str = end.strftime("%Y%m%d")

    # Prix spot Day-Ahead
    spot_source = PythonEntsoeSource(
        api_key=ENTSOE_TOKEN,
        start=start_str,
        end=end_str,
        country_code='FR',
        document_type='A44'
    )
    df_spot = spot_source.read_batch()
    if not df_spot.empty:
        df_spot["timestamp"] = df_spot["datetime"]
        write_dataframe_to_influx(df_spot, "spot_price_epex", "value")

    # Activations réelles mFRR
    mfrr_source = PythonEntsoeSource(
        api_key=ENTSOE_TOKEN,
        start=start_str,
        end=end_str,
        country_code='FR',
        document_type='A75'
    )
    df_mfrr = mfrr_source.read_batch()
    if not df_mfrr.empty:
        df_mfrr["timestamp"] = df_mfrr["datetime"]
        write_dataframe_to_influx(df_mfrr, "real_mfrr_activations", "value")

    # Activations réelles aFRR
    afrr_source = PythonEntsoeSource(
        api_key=ENTSOE_TOKEN,
        start=start_str,
        end=end_str,
        country_code='FR',
        document_type='A75'
    )
    df_afrr = afrr_source.read_batch()
    if not df_afrr.empty:
        df_afrr["timestamp"] = df_afrr["datetime"]
        write_dataframe_to_influx(df_afrr, "real_afrr_activations", "value")

if __name__ == "__main__":
    fetch_and_store_data()
