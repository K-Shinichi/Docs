import time
import random
from datetime import datetime
from influxdb_client import InfluxDBClient, Point
from influxdb_client.client.write_api import SYNCHRONOUS
from dotenv import load_dotenv
import os
import requests

load_dotenv()

bucket = os.getenv("INFLUXDB_BUCKET")
org = os.getenv("INFLUXDB_ORG")
token = os.getenv("INFLUXDB_TOKEN")
url = os.getenv("INFLUXDB_URL")

client = InfluxDBClient(url=url, token=token, org=org)
write_api = client.write_api(write_options=SYNCHRONOUS)


# Attendre que InfluxDB soit prêt (jusqu'à 60s)
for _ in range(30):
    try:
        r = requests.get("http://influxdb:8086/health")
        if r.status_code == 200:
            print("✅ InfluxDB est prêt")
            break
    except:
        pass
    print("⏳ En attente de InfluxDB...")
    time.sleep(2)

while True:
    now = datetime.utcnow()
    frequency = round(random.uniform(49.75, 50.25), 3)
    mFRR = random.randint(0, 80)
    aFRR = random.randint(0, 50)

    # Écrire fréquence
    point_freq = Point("frequency_data").field("hz", frequency).time(now)
    write_api.write(bucket=bucket, org=org, record=point_freq)

    # Écrire mFRR
    point_mfrr = Point("mFRR_activations").field("mw", mFRR).time(now)
    write_api.write(bucket=bucket, org=org, record=point_mfrr)

    # Écrire aFRR
    point_afrr = Point("aFRR_activations").field("mw", aFRR).time(now)
    write_api.write(bucket=bucket, org=org, record=point_afrr)

    # Simuler décision NEBEF si freq < 49.85 Hz
    if frequency < 49.85:
        point_nebef = Point("nebef_decisions").tag("site", "demo_site") \
            .field("activated", 1).field("mw_saved", 2.5).time(now)
        write_api.write(bucket=bucket, org=org, record=point_nebef)

    print(f"[{now}] Hz: {frequency} | mFRR: {mFRR} MW | aFRR: {aFRR} MW")

    time.sleep(60)

