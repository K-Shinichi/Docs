import time
import requests
import os
from influxdb_client import InfluxDBClient, Point
from dotenv import load_dotenv
from datetime import datetime

load_dotenv()

RTE_CLIENT_ID = os.getenv("RTE_CLIENT_ID")
RTE_CLIENT_SECRET = os.getenv("RTE_CLIENT_SECRET")
INFLUXDB_TOKEN = os.getenv("INFLUXDB_TOKEN")
INFLUXDB_URL = os.getenv("INFLUXDB_URL")
INFLUXDB_ORG = os.getenv("INFLUXDB_ORG")
INFLUXDB_BUCKET = os.getenv("INFLUXDB_BUCKET")

def get_rte_token():
    url = "https://digital.iservices.rte-france.com/token/oauth/"
    headers = {"Content-Type": "application/x-www-form-urlencoded"}
    data = {
        "grant_type": "client_credentials",
        "client_id": RTE_CLIENT_ID,
        "client_secret": RTE_CLIENT_SECRET
    }
    response = requests.post(url, headers=headers, data=data)
    return response.json().get("access_token")

def fetch_frequency(token):
    return 49.80 + (0.4 * (datetime.utcnow().second % 10) / 10)

def simulate_nebef(frequency):
    if frequency < 49.85:
        return True, 1500
    return False, 0

def simulate_mfrr():
    return 25 + (datetime.utcnow().second % 10)

def fetch_afrr(token):
    return 30 + (datetime.utcnow().second % 7)

def write_to_influx(freq, nebef, mfrr, afrr):
    client = InfluxDBClient(url=INFLUXDB_URL, token=INFLUXDB_TOKEN, org=INFLUXDB_ORG)
    write_api = client.write_api()
    points = [
        Point("frequency_data").field("hz", freq),
        Point("mFRR_activations").field("mw", mfrr),
        Point("aFRR_activations").field("mw", afrr)
    ]
    if nebef[0]:
        points.append(Point("nebef_decisions").field("revenue", nebef[1]))
    for p in points:
        write_api.write(bucket=INFLUXDB_BUCKET, record=p)
    client.close()

if __name__ == "__main__":
    token = get_rte_token()
    while True:
        freq = fetch_frequency(token)
        nebef = simulate_nebef(freq)
        mfrr = simulate_mfrr()
        afrr = fetch_afrr(token)
        write_to_influx(freq, nebef, mfrr, afrr)
        time.sleep(60)

