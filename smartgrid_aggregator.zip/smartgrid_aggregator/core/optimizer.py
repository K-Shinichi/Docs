# À remplir : logique de décision sur mFRR / NEBEF
def make_decision(frequency, spot_price, site):
    if frequency < 49.8 and site["available"]:
        return "activate"
    return "do_nothing"

