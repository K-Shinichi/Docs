from datetime import datetime, timedelta
import requests
from data_sources.rte_auth import get_rte_token

def fetch_frequency(token):
    url = "https://digital.iservices.rte-france.com/open_api/real_time_data/v4/frequency"
    headers = {"Authorization": f"Bearer {token}"}
    end = datetime.utcnow()
    start = end - timedelta(minutes=15)
    params = {
        "start_date": start.isoformat(),
        "end_date": end.isoformat()
    }
    response = requests.get(url, headers=headers, params=params)
    return response.json()

