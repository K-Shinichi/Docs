import time
from datetime import datetime
import pandas as pd
from rte_auth import get_rte_token
from rte_frequency import fetch_frequency

client_id = "TON_CLIENT_ID"
client_secret = "TON_SECRET"
token = get_rte_token(client_id, client_secret)

def loop_fetch():
    while True:
        try:
            data = fetch_frequency(token)
            rows = []
            for point in data["frequency_values"]:
                ts = point["timestamp"]
                val = float(point["value"])
                rows.append({"timestamp": ts, "frequency_Hz": val})

            df = pd.DataFrame(rows)
            df.to_csv("data_sources/frequency_live.csv", index=False)

            print(f"{datetime.now()} — Données fréquence mises à jour.")
        except Exception as e:
            print("Erreur :", e)

        time.sleep(60)  # Attendre 1 minute avant relance

if __name__ == "__main__":
    loop_fetch()

