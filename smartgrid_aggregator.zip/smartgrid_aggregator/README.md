# SmartGrid Aggregator

Ce projet vise à construire une plateforme d’analyse et de décision énergétique en utilisant des données réelles (RTE, EPEX), Python et des dashboards.

