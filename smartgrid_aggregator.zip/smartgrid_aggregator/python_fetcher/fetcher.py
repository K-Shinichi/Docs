import os
import time
import requests
from datetime import datetime, timedelta
from influxdb_client import InfluxDBClient, Point, WritePrecision

def get_rte_token(client_id, client_secret):
    url = "https://digital.iservices.rte-france.com/token/oauth/"
    payload = {
        'client_id': client_id,
        'client_secret': client_secret,
        'grant_type': 'client_credentials'
    }
    r = requests.post(url, data=payload)
    r.raise_for_status()
    return r.json()['access_token']

def fetch_rte_frequency(token):
    end = datetime.utcnow()
    start = end - timedelta(minutes=2)
    headers = {"Authorization": f"Bearer {token}"}
    params = {
        "start_date": start.isoformat(),
        "end_date": end.isoformat()
    }
    url = "https://digital.iservices.rte-france.com/open_api/real_time_data/v4/frequency"
    r = requests.get(url, headers=headers, params=params)
    r.raise_for_status()
    data = r.json()
    last_point = data["frequency_values"][-1]
    return float(last_point["value"])

# Get env
client_id = os.environ.get("RTE_CLIENT_ID")
client_secret = os.environ.get("RTE_CLIENT_SECRET")
bucket = os.environ.get("INFLUXDB_BUCKET")
org = os.environ.get("INFLUXDB_ORG")
token_db = os.environ.get("INFLUXDB_TOKEN")
url = os.environ.get("INFLUXDB_URL")

client = InfluxDBClient(url=url, token=token_db, org=org)
write_api = client.write_api(write_options=WritePrecision.NS)

# Auth
token = get_rte_token(client_id, client_secret)

while True:
    try:
        freq = fetch_rte_frequency(token)
        now = datetime.utcnow()
        point = Point("frequency_data").field("hz", freq).time(now, WritePrecision.NS)
        write_api.write(bucket=bucket, org=org, record=point)
        print(f"[{now}] Frequency: {freq} Hz")

        # Simuler une décision NEBEF aléatoire
        if freq < 49.85:
            nebef = Point("nebef_decisions").tag("site", "usine_1").field("revenue", 43.5).time(now, WritePrecision.NS)
            write_api.write(bucket=bucket, org=org, record=nebef)
            print(f"[{now}] NEBEF activation simulée")
    except Exception as e:
        print("Erreur:", e)

    time.sleep(60)

